'use strict';
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
let latest = null;
let history = [];
let toastTimer;
const scenarios = {
  refund: {message:'Your refund of Rs. 5000 is pending. Scan this QR code and enter your UPI PIN to receive the money immediately.', context:'The caller says they are refunding a cancelled order. They want me to scan this QR to receive it.', intent:'receive', qr_data:'upi://pay?pa=unknownmerchant@example&pn=UnknownMerchant&am=5000&cu=INR', expected_payee:'', expected_amount:5000},
  kyc: {message:'URGENT! Your KYC has expired. Your account will be blocked. Update KYC immediately to restore your account.', context:'I received this unexpected account verification request by SMS.', intent:'unsure', qr_data:'', expected_payee:'', expected_amount:''},
  recipient: {message:'Here is the payment QR for your order. Please pay Rs. 500.', context:'I am standing at Sample Store. The printed QR has a different name and amount.', intent:'send', qr_data:'upi://pay?pa=otheraccount@example&pn=OtherAccount&am=5000&cu=INR', expected_payee:'Sample Store', expected_amount:500},
  normal: {message:'Please pay Rs. 500 for your order at Sample Store.', context:'I am buying groceries at the counter. The name and amount match my bill.', intent:'send', qr_data:'upi://pay?pa=samplestore@example&pn=Sample%20Store&am=500&cu=INR', expected_payee:'Sample Store', expected_amount:500}
};

function toast(message) {
  $('toast').textContent = message; $('toast').classList.remove('hidden');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.add('hidden'), 4500);
}
async function api(path, options = {}) {
  const response = await fetch(path, {...options, headers: {'Content-Type':'application/json', ...options.headers}});
  let data;
  try { data = await response.json(); } catch { throw new Error('The server returned an unreadable response.'); }
  if (!response.ok) {
    const detail = Array.isArray(data.detail) ? data.detail.map(item => item.msg).join(' ') : data.detail;
    throw new Error(detail || `Request failed (${response.status}).`);
  }
  return data;
}
function switchView(view) {
  document.querySelectorAll('.view').forEach(item => item.classList.toggle('hidden', item.id !== `view-${view}`));
  document.querySelectorAll('.nav-item').forEach(item => { item.classList.toggle('active', item.dataset.view === view); item.setAttribute('aria-current', item.dataset.view === view ? 'page' : 'false'); });
  if (view === 'history') refreshHistory();
  window.scrollTo({top:0, behavior:'smooth'});
}
document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => switchView(button.dataset.view)));
function clearResult() {
  latest = null; $('resultContent').classList.add('hidden'); $('emptyResult').classList.remove('hidden');
}
document.querySelectorAll('[data-scenario]').forEach(button => button.addEventListener('click', () => {
  const scenario = scenarios[button.dataset.scenario];
  for (const [id, key] of [['message','message'],['context','context'],['qrData','qr_data'],['expectedPayee','expected_payee'],['expectedAmount','expected_amount']]) $(id).value = scenario[key];
  document.querySelector(`input[name="intent"][value="${scenario.intent}"]`).checked = true;
  $('qrStatus').textContent = 'Sample payment data loaded. No real account is used.';
  $('saveReview').checked = false; clearResult(); toast('Scenario loaded. Select “Review this payment” to connect the dots.');
  $('qrImage').value = ''; $('screenshot').value = ''; $('ocrStatus').textContent = '';
  $('screenshotPanel').classList.add('hidden');
  document.querySelectorAll('[data-input]').forEach(item => item.classList.toggle('active', item.dataset.input === 'paste'));
}));
document.querySelectorAll('[data-input]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-input]').forEach(item => item.classList.toggle('active', item === button));
  $('screenshotPanel').classList.toggle('hidden', button.dataset.input !== 'screenshot');
}));
$('checkForm').addEventListener('input', event => {
  if (!['saveReview','useLlm'].includes(event.target.id) && latest) clearResult();
});
$('checkForm').addEventListener('submit', async event => {
  event.preventDefault();
  const payload = {message:$('message').value.trim(), context:$('context').value.trim(), qr_data:$('qrData').value.trim(), intent:document.querySelector('input[name="intent"]:checked').value, expected_payee:$('expectedPayee').value.trim(), expected_amount:$('expectedAmount').value ? Number($('expectedAmount').value) : null, save_review:$('saveReview').checked, use_llm:$('useLlm').checked};
  if (!payload.message && !payload.context && !payload.qr_data) { toast('Add a message, caller context or UPI QR first.'); $('message').focus(); return; }
  // Freeze inputs so results always correspond to the information shown.
  const controls = [...$('checkForm').querySelectorAll('input,textarea,button'), ...document.querySelectorAll('[data-scenario]')];
  controls.forEach(control => control.disabled = true);
  $('emptyResult').classList.add('hidden'); $('resultContent').classList.add('hidden'); $('loadingResult').classList.remove('hidden');
  try {
    latest = await api('/analyze', {method:'POST', body:JSON.stringify(payload)});
    displayResult(latest);
    if (latest.saved) await refreshHistory();
    if (window.innerWidth <= 700) $('resultCard').scrollIntoView({behavior:'smooth', block:'start'});
  } catch (error) { $('emptyResult').classList.remove('hidden'); toast(`Unable to review: ${error.message}`); }
  finally { $('loadingResult').classList.add('hidden'); controls.forEach(control => control.disabled = false); }
});

function paymentMarkup(data) {
  const payment = data.payment_details;
  return `<div class="payment-details">${[['Action',payment.action],['Recipient',payment.payee_name || 'Not provided'],['UPI address',payment.payee_address || 'Not provided'],['Amount',payment.amount ? `${payment.amount} ${payment.currency}` : 'Not specified']].map(([key,value]) => `<div class="detail-row"><span>${escapeHtml(key)}</span><b>${escapeHtml(value)}</b></div>`).join('')}</div>`;
}
function displayResult(data) {
  const risk = ['HIGH','MEDIUM','LOW'].includes(data.risk) ? data.risk : 'LOW';
  $('resultContent').innerHTML = `
    ${data.context_review ? `<div class="action-card"><strong>Local LLM context assessment · ${escapeHtml(data.context_review.risk)}</strong><p>${escapeHtml(data.context_review.explanation)}</p>${data.context_review.evidence.map(item => `<p><b>${escapeHtml(item.source)}:</b> “${escapeHtml(item.quote)}”<br>${escapeHtml(item.reason)}</p>`).join('')}<p class="hint">${escapeHtml(data.explanation_source)} · A validated HIGH assessment raises the final score to at least 75. Model judgment is not verified fraud status.</p></div>` : `<p class="hint">${escapeHtml(data.llm_status)}</p>`}
    <div class="risk-summary ${risk.toLowerCase()}"><div class="risk-top"><span class="risk-label">${risk === 'HIGH' ? '⚑ ' : ''}${risk} RISK INDICATORS</span><span class="risk-score">${Number(data.score)}<small> / 100</small></span></div><div class="score-track"><span style="width:${Number(data.score)}%"></span></div><p>${escapeHtml(data.summary)}</p></div>
    <div class="result-section-label">WHAT THE EVIDENCE SAYS</div>
    ${data.evidence.length ? data.evidence.map(item => `<article class="evidence-item"><div class="evidence-heading"><span>${escapeHtml(item.title)}</span><b>+${Number(item.weight)} pts</b></div><p>${escapeHtml(item.detail)}</p><span class="evidence-source">${escapeHtml(item.source)}</span></article>`).join('') : '<p class="hint">No strong rule-based warning signs in the supplied information. This does not verify safety.</p>'}
    ${data.qr_payment_detected ? `<div class="result-section-label">WHAT THIS QR REQUESTS</div>${paymentMarkup(data)}` : ''}
    <div class="action-card"><strong>A clearer next step</strong><p>${escapeHtml(data.recommendation)}</p></div>
    ${data.missing_context.length ? `<div class="result-section-label">STILL UNKNOWN</div><ul class="gaps">${data.missing_context.map(gap => `<li>${escapeHtml(gap)}</li>`).join('')}</ul>` : ''}
    <details class="model-info"><summary>How this review was produced</summary><p>Rule points: ${data.rule_score} · ML contribution: ${data.ml_points} · Applied score floor: ${data.score_floor ?? 0} · Final score capped at 100.</p><p>Floor reasons: ${escapeHtml((data.score_floor_reasons || []).join(', ') || 'none')}. A validated HIGH LLM assessment or high-severity rule enforces 75–100.</p><p>${escapeHtml(data.ml.model)}: ${escapeHtml(data.ml.label)}. ${escapeHtml(data.ml.training)}.</p><p>Model signal: ${data.ml.model_score ?? 'unavailable'} (not a validated fraud probability). ML only adds 10 points when its signal is at least 0.75; it cannot reduce rule evidence.</p><p>Explanation: ${escapeHtml(data.explanation_source)}. ${escapeHtml(data.llm_status)}</p><p>${escapeHtml(data.explanation)}</p><p>${data.limitations.map(escapeHtml).join(' ')}</p></details>
    <div class="result-actions">${data.qr_payment_detected ? '<button type="button" class="primary" id="previewPayment">Review payment ↗</button>' : ''}<button type="button" class="secondary" id="downloadReport">Export review ↓</button></div>
    ${data.saved ? '<div class="feedback-row"><span>Was this explanation useful?</span><button type="button" data-useful="yes">Yes</button><button type="button" data-useful="no">No</button></div>' : ''}
    <div class="result-meta">${data.duration_ms} ms · ${data.saved ? 'Saved on this laptop' : 'Not saved'} · Recipient ownership unverified</div>`;
  $('emptyResult').classList.add('hidden'); $('resultContent').classList.remove('hidden');
  if ($('previewPayment')) $('previewPayment').addEventListener('click', () => {
    $('paymentPreview').innerHTML = paymentMarkup(data);
    $('paymentDialog').showModal();
  });
  $('downloadReport').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = `scamsense-${data.id}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  document.querySelectorAll('[data-useful]').forEach(button => button.addEventListener('click', async () => {
    try { await api(`/reviews/${encodeURIComponent(data.id)}/feedback`, {method:'POST',body:JSON.stringify({label:'unsure', useful:button.dataset.useful === 'yes'})}); toast('Thank you. Explanation feedback saved.'); document.querySelectorAll('[data-useful]').forEach(item => item.disabled = true); await refreshHistory(); }
    catch (error) { toast(error.message); }
  }));
}
$('closeDialog').addEventListener('click', () => $('paymentDialog').close());
$('pausePayment').addEventListener('click', () => { $('paymentDialog').close(); toast('Payment review paused. Verify through an independent contact or official app.'); });

async function refreshHistory() {
  try {
    history = await api('/reviews'); $('savedCount').textContent = history.length;
    const flagged = history.filter(item => item.risk !== 'LOW').length;
    const feedbackCount = history.filter(item => item.feedback).length;
    $('historySummary').textContent = `${history.length} saved reviews · ${flagged} with elevated indicators · ${feedbackCount} usefulness responses`;
    $('historyList').innerHTML = history.length ? history.map((item,index) => `<article class="card history-card"><span class="risk-label ${item.risk.toLowerCase()}">${escapeHtml(item.risk)} · ${item.score}</span><div><p>${escapeHtml(item.summary)}</p><small>${escapeHtml(new Date(item.created_at).toLocaleString())} · ${item.duration_ms} ms · ${item.feedback ? 'Feedback recorded' : 'No feedback'}</small></div><button class="secondary" data-review="${index}">Open review ↗</button></article>`).join('') : '<div class="card"><h2>A fresh start.</h2><p class="hint">Enable “Save this review on this laptop” before analyzing to keep a review here. Original messages and images are not stored; the resulting evidence may contain recipient details.</p></div>';
    document.querySelectorAll('[data-review]').forEach(button => button.addEventListener('click', () => {
      const data = history[Number(button.dataset.review)]; switchView('check'); latest = data; displayResult(data);
      $('resultCard').scrollIntoView({behavior:'smooth',block:'start'}); toast('Viewing a saved review. It is separate from the current form inputs.');
    }));
  } catch (error) { $('historySummary').textContent = `Could not load reviews: ${error.message}`; }
}
$('deleteHistory').addEventListener('click', async () => {
  if (!history.length) { toast('There are no saved reviews to delete.'); return; }
  if (!confirm('Delete all saved reviews and feedback from this laptop?')) return;
  try { await api('/reviews', {method:'DELETE'}); await refreshHistory(); clearResult(); toast('Saved reviews deleted.'); }
  catch (error) { toast(error.message); }
});

const scriptLoads = new Map();
function loadScript(source) {
  if (!scriptLoads.has(source)) {
    const promise = new Promise((resolve,reject) => {
      const script = document.createElement('script'); script.src = source;
      const timeout = setTimeout(() => {script.remove(); reject(new Error('Download timed out. Check internet and try again.'));}, 30000);
      script.onload = () => {clearTimeout(timeout); resolve();};
      script.onerror = () => {clearTimeout(timeout); script.remove(); reject(new Error('Could not load extraction library. Paste the content manually.'));};
      document.head.appendChild(script);
    }).catch(error => {scriptLoads.delete(source); throw error;});
    scriptLoads.set(source,promise);
  }
  return scriptLoads.get(source);
}
function validateImage(file) {
  if (!file) throw new Error('Choose an image first.');
  if (!['image/png','image/jpeg','image/webp'].includes(file.type)) throw new Error('Choose a PNG, JPG or WebP image.');
  if (file.size > 8 * 1024 * 1024) throw new Error('Image must be smaller than 8 MB.');
}
function setExtractionBusy(busy) {
  ['qrImage','screenshot','ocrButton','analyzeButton'].forEach(id => $(id).disabled = busy);
  document.querySelectorAll('[data-scenario]').forEach(button => button.disabled = busy);
}
$('qrImage').addEventListener('change', async () => {
  const input = $('qrImage'); const file = input.files[0]; if (!file) return;
  let bitmap;
  setExtractionBusy(true);
  $('qrStatus').textContent = 'Reading QR image…';
  try {
    validateImage(file);
    await loadScript('https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js');
    bitmap = await createImageBitmap(file);
    const canvas = document.createElement('canvas');
    // Retain enough pixels for dense QR codes while bounding browser memory.
    const scale = Math.min(1, 2000 / Math.max(bitmap.width, bitmap.height));
    canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
    const drawing = canvas.getContext('2d', {willReadFrequently:true});
    drawing.fillStyle = '#fff'; drawing.fillRect(0,0,canvas.width,canvas.height);
    drawing.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const pixels = drawing.getImageData(0,0,canvas.width,canvas.height);
    const decoded = jsQR(pixels.data, pixels.width, pixels.height, {inversionAttempts:'attemptBoth'});
    if (!decoded) throw new Error('No QR code found. Try a clearer image or paste the UPI link.');
    const text = decoded.data;
    $('qrData').value = text; clearResult();
    $('qrStatus').textContent = text.toLowerCase().startsWith('upi://pay?') ? 'UPI QR decoded. Check the recipient and amount in your review.' : 'QR decoded, but it is not a supported UPI payment link.';
  } catch (error) { $('qrStatus').textContent = `Could not read QR: ${error.message || 'Try a clearer image or paste the UPI link.'}`; }
  finally { if (bitmap) bitmap.close(); setExtractionBusy(false); }
});
$('ocrButton').addEventListener('click', async () => {
  let worker;
  setExtractionBusy(true);
  try {
    const file = $('screenshot').files[0]; validateImage(file);
    $('ocrStatus').textContent = 'Loading browser OCR…';
    await loadScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');
    worker = await Tesseract.createWorker('eng', 1, {logger: event => { if (event.status) $('ocrStatus').textContent = `${event.status} ${Math.round((event.progress || 0) * 100)}%`; }});
    const {data} = await worker.recognize(file);
    if (!data.text.trim()) throw new Error('No readable text found. Try a clearer screenshot.');
    $('message').value = data.text.trim(); clearResult();
    $('ocrStatus').textContent = 'Text extracted. Review and correct it before analyzing.';
  } catch (error) { $('ocrStatus').textContent = `OCR unavailable: ${error.message}`; }
  finally { if (worker) { try { await worker.terminate(); } catch {} } setExtractionBusy(false); }
});
async function initialize() {
  try {
    const health = await api('/health'); $('serverStatus').textContent = 'Local server online';
    $('llmAvailability').textContent = health.llm_ready ? `(${health.llm_model} ready)` : health.llm_configured ? '(model unavailable)' : '(not configured)';
    $('useLlm').checked = health.llm_configured;
    $('useLlm').disabled = !health.llm_configured;
    $('useLlm').title = health.llm_configured ? 'Uses the configured local Ollama model' : 'Set SCAMSENSE_OLLAMA_MODEL and start Ollama to enable';
  } catch { $('serverStatus').textContent = 'Server unavailable'; }
  await refreshHistory();
}
initialize();
